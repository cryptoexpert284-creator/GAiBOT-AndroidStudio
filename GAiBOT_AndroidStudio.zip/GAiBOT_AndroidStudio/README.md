# GAi BOT Android Studio starter

This is an Android Studio **starter project**, not a completed port of the Chrome extension and not a finished APK. It implements a basic native app shell, the Android overlay-permission flow, a movable floating popup, and the user-consented MediaProjection screen-capture session.

## Open it
1. Unzip this folder.
2. Open Android Studio and choose **Open**; select this `GAiBOT_AndroidStudio` folder.
3. Use JDK 17 and allow Gradle sync/downloads.
4. Build > Build APK(s). GitHub Actions workflow is also included under `.github/workflows/android.yml`.

## Current status
- Implemented: Android project structure, home screen, overlay permission request, movable floating control, MediaProjection consent and foreground capture service.
- Not implemented yet: OCR/candle recognition from captured pixels, accurate timeframe/market detection from Binance screen, port of the eight-strategy engine, live signal/TP/SL display in the overlay, continuous scan scheduler, and device testing.
- Original extension files are preserved under `app/src/main/assets/legacy-extension/` for porting reference.

## Important technical note
Chrome extension content scripts cannot run directly inside the Binance Android app. Screen capture requires the user to grant Android's system consent. The capture service currently creates a virtual display but does not interpret pixels or emit trading signals. Do not treat this starter as a working trading scanner. Signals and TP/SL are not guaranteed and it does not place orders.
