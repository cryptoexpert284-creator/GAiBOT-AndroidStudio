package com.gaibot.android

import android.app.Service
import android.content.Intent
import android.graphics.Color
import android.graphics.PixelFormat
import android.graphics.Typeface
import android.graphics.drawable.GradientDrawable
import android.os.IBinder
import android.view.Gravity
import android.view.WindowManager
import android.view.MotionEvent
import android.widget.LinearLayout
import android.widget.TextView

class OverlayService : Service() {
    private lateinit var wm: WindowManager
    private var panel: LinearLayout? = null
    private var params: WindowManager.LayoutParams? = null
    override fun onBind(intent: Intent?): IBinder? = null
    override fun onStartCommand(intent: Intent?, flags: Int, startId: Int): Int { if (panel == null) showPanel(); return START_STICKY }
    private fun showPanel() {
        wm = getSystemService(WINDOW_SERVICE) as WindowManager
        val box = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL; setPadding(16,12,16,12); background = GradientDrawable().apply { setColor(Color.rgb(25,28,39)); cornerRadius=24f; setStroke(2, Color.rgb(240,185,11)) } }
        val title = TextView(this).apply { text="GAi BOT  ⋮"; textSize=16f; setTextColor(Color.rgb(240,185,11)); typeface=Typeface.DEFAULT_BOLD; gravity=Gravity.CENTER; setPadding(4,4,4,10) }
        val status = TextView(this).apply { text="Popup ready · open Binance"; textSize=12f; setTextColor(Color.WHITE); gravity=Gravity.CENTER; setPadding(4,4,4,8) }
        val scan = TextView(this).apply { text="START SCREEN SCAN"; textSize=12f; setTextColor(Color.BLACK); gravity=Gravity.CENTER; setPadding(12,12,12,12); background=GradientDrawable().apply { setColor(Color.rgb(240,185,11)); cornerRadius=14f } }
        scan.setOnClickListener { status.text = "Screen capture must be enabled in GAi BOT first. Chart OCR/strategy engine not integrated yet." }
        val close = TextView(this).apply { text="CLOSE POPUP"; textSize=11f; setTextColor(Color.LTGRAY); gravity=Gravity.CENTER; setPadding(8,10,8,2); setOnClickListener { stopSelf() } }
        box.addView(title); box.addView(status); box.addView(scan); box.addView(close)
        val type = if (android.os.Build.VERSION.SDK_INT >= 26) WindowManager.LayoutParams.TYPE_APPLICATION_OVERLAY else @Suppress("DEPRECATION") WindowManager.LayoutParams.TYPE_PHONE
        val lp = WindowManager.LayoutParams(WindowManager.LayoutParams.WRAP_CONTENT, WindowManager.LayoutParams.WRAP_CONTENT, type, WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE or WindowManager.LayoutParams.FLAG_LAYOUT_IN_SCREEN, PixelFormat.TRANSLUCENT).apply { gravity=Gravity.TOP or Gravity.END; x=24; y=180 }
        title.setOnTouchListener(object : android.view.View.OnTouchListener { var sx=0f; var sy=0f; var ox=0; var oy=0; override fun onTouch(v: android.view.View, e: MotionEvent): Boolean { when(e.action) { MotionEvent.ACTION_DOWN -> { sx=e.rawX; sy=e.rawY; ox=lp.x; oy=lp.y; return true }; MotionEvent.ACTION_MOVE -> { lp.x=(ox+(sx-e.rawX)).toInt(); lp.y=(oy+(e.rawY-sy)).toInt(); wm.updateViewLayout(box,lp); return true } }; return false } })
        wm.addView(box,lp); panel=box; params=lp
    }
    override fun onDestroy() { panel?.let { try { wm.removeView(it) } catch (_: Exception) {} }; panel=null; super.onDestroy() }
}
