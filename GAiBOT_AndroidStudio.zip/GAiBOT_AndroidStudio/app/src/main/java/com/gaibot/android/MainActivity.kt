package com.gaibot.android

import android.app.Activity
import android.content.Intent
import android.media.projection.MediaProjectionManager
import android.net.Uri
import android.os.Bundle
import android.provider.Settings
import android.view.Gravity
import android.view.ViewGroup
import android.widget.Button
import android.widget.LinearLayout
import android.widget.TextView
import android.graphics.Color

class MainActivity : Activity() {
    private val captureRequest = 4102
    private lateinit var projectionManager: MediaProjectionManager
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        projectionManager = getSystemService(MEDIA_PROJECTION_SERVICE) as MediaProjectionManager
        val root = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL; gravity = Gravity.CENTER; setPadding(28, 32, 28, 32); setBackgroundColor(Color.rgb(18,20,28)) }
        fun label(text: String, size: Float, color: Int = Color.WHITE) = TextView(this).apply { this.text=text; textSize=size; setTextColor(color); gravity=Gravity.CENTER; setPadding(0,12,0,12) }
        root.addView(label("GAi BOT", 28f))
        root.addView(label("Android conversion starter", 16f, Color.rgb(240,185,11)))
        root.addView(label("This build can request screen capture and show a floating control. Chart recognition and the original 8-strategy engine still need Android integration and testing.", 15f))
        val overlay = Button(this).apply { text = "ENABLE FLOATING POPUP"; setOnClickListener { enableOverlayAndStart() } }
        root.addView(overlay, LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT))
        val capture = Button(this).apply { text = "ALLOW SCREEN CAPTURE"; setOnClickListener { startActivityForResult(projectionManager.createScreenCaptureIntent(), captureRequest) } }
        root.addView(capture, LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT))
        root.addView(label("No trades are placed. Signals are not guaranteed. Keep Binance visible during capture.", 12f, Color.LTGRAY))
        setContentView(root)
    }
    private fun enableOverlayAndStart() {
        if (!Settings.canDrawOverlays(this)) {
            startActivity(Intent(Settings.ACTION_MANAGE_OVERLAY_PERMISSION, Uri.parse("package:$packageName")))
            return
        }
        startService(Intent(this, OverlayService::class.java))
    }
    @Deprecated("Deprecated in Android API; kept for broad device compatibility")
    override fun onActivityResult(requestCode: Int, resultCode: Int, data: Intent?) {
        super.onActivityResult(requestCode, resultCode, data)
        if (requestCode == captureRequest && resultCode == RESULT_OK && data != null) {
            val intent = Intent(this, CaptureService::class.java).apply { putExtra(CaptureService.EXTRA_RESULT_CODE, resultCode); putExtra(CaptureService.EXTRA_DATA, data) }
            startForegroundService(intent)
        }
    }
}
