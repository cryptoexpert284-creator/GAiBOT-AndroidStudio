package com.gaibot.android

import android.app.Notification
import android.app.NotificationChannel
import android.app.NotificationManager
import android.app.Service
import android.content.Context
import android.content.Intent
import android.media.ImageReader
import android.media.projection.MediaProjection
import android.media.projection.MediaProjectionManager
import android.os.Build
import android.os.IBinder
import android.util.DisplayMetrics
import android.view.WindowManager

class CaptureService : Service() {
    companion object { const val EXTRA_RESULT_CODE="result_code"; const val EXTRA_DATA="projection_data"; private const val CHANNEL="gai_screen_capture" }
    private var projection: MediaProjection? = null
    private var reader: ImageReader? = null
    override fun onBind(intent: Intent?): IBinder? = null
    override fun onStartCommand(intent: Intent?, flags: Int, startId: Int): Int {
        createNotificationChannel()
        startForeground(72, Notification.Builder(this, CHANNEL).setContentTitle("GAi BOT screen capture").setContentText("Screen capture is active; chart recognition is not yet integrated.").setSmallIcon(android.R.drawable.ic_menu_view).build())
        val code=intent?.getIntExtra(EXTRA_RESULT_CODE,0) ?: 0
        val data=intent?.getParcelableExtra<Intent>(EXTRA_DATA)
        if (data != null && projection == null) {
            val mgr=getSystemService(Context.MEDIA_PROJECTION_SERVICE) as MediaProjectionManager
            projection=mgr.getMediaProjection(code,data)
            val metrics=DisplayMetrics()
            @Suppress("DEPRECATION") (getSystemService(WINDOW_SERVICE) as WindowManager).defaultDisplay.getRealMetrics(metrics)
            reader=ImageReader.newInstance(metrics.widthPixels.coerceAtLeast(1), metrics.heightPixels.coerceAtLeast(1), android.graphics.PixelFormat.RGBA_8888, 2)
            projection?.createVirtualDisplay("GAiBOTScreen", metrics.widthPixels, metrics.heightPixels, metrics.densityDpi, 0, reader?.surface, null, null)
        }
        return START_NOT_STICKY
    }
    private fun createNotificationChannel() { if (Build.VERSION.SDK_INT >= 26) { val nm=getSystemService(NotificationManager::class.java); nm.createNotificationChannel(NotificationChannel(CHANNEL,"GAi BOT screen capture",NotificationManager.IMPORTANCE_LOW)) } }
    override fun onDestroy() { projection?.stop(); projection=null; reader?.close(); reader=null; super.onDestroy() }
}
